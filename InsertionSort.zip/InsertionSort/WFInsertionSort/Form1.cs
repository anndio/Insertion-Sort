﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Diagnostics;

namespace WFInsertionSort
{
    public partial class Form1 : Form
    {
        public static SortedDictionary<int, int> Graf = new SortedDictionary<int, int>();
        public static int Num;
        public static string algoTime;
        public int Len;
        bool FirstClicl = false;

        public Form1()
        {
            InitializeComponent();
            chart1.Series[1].Points.Clear();
            GrafDict();
            PaintGraf();
            for (int n = 0; n <= 100; n++)
                chart1.Series[0].Points.AddXY(n, n * n);
        }

        public void GrafDict()
        {
            StreamReader sr = new StreamReader("point.txt");
            int n = int.Parse(sr.ReadLine());
            Num = n;
            for (int i = 0; i < n; i++)
            {
                string[] temp = sr.ReadLine().Split();
                string temp_Index = temp[0];
                string temp_Num = temp[1];

                if (!Graf.ContainsKey(int.Parse(temp_Index)))
                    Graf.Add(int.Parse(temp_Index), (int.Parse(temp_Num)));
                else
                    Graf[int.Parse(temp_Index)] = int.Parse(temp_Num);
            }
            sr.Close();
        }

        public void PaintGraf()
        {
            chart1.Series[1].Points.Clear();
            foreach (var item in Graf)
                chart1.Series[1].Points.AddXY(item.Key, item.Value);
        }

        static void InsertionSort(int n, int[] array)
        {
            for (int i = 1; i < n; i++)
                for (int j = i; j > 0 && array[j] < array[j - 1]; j--)
                {
                    int a = array[j];
                    array[j] = array[j - 1];
                    array[j - 1] = a;
                }
        }
        
        private void OpenButton_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "Text files (*.txt)|*.txt";
            if (Convert.ToBoolean(openFileDialog.ShowDialog()) == true)
                textBox1.Text = File.ReadAllText(openFileDialog.FileName);
        }

        private void RandomButton_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";
            Random rand = new Random();
            int n = rand.Next(2,100);
            Len = n;
            int[] array = new int[n];
            for (int i = 0; i < n; i++)
            {
                array[i] = rand.Next(-100, 100);
            }
            for (int i = 0; i < n; i++)
            {
                textBox1.Text += array[i] + " ";
            }
        }

        private void SaveButton_Click(object sender, EventArgs e)
        {
            SaveFileDialog saveFileDialog = new SaveFileDialog();
            saveFileDialog.Filter = "Text file (*.txt)|*.txt";
            if (Convert.ToBoolean(saveFileDialog.ShowDialog()) == true)
                File.WriteAllText(saveFileDialog.FileName, textBox2.Text);
        }

        private void ClearButton_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";
            textBox2.Text = "";
            TimeBox.Text = "";
        }

        private void SortButton_Click(object sender, EventArgs e)
        {
            string[] s = textBox1.Text.Split();
            int n = s.Length;
            Len = n;
            int[] array = new int[n];
            for (int i = 0; i < n; i++)
            {
                if (s[i] != "")
                    array[i] = Convert.ToInt32(s[i]);
                else n = n - 1;
            }

            Stopwatch time = new Stopwatch();
            time.Start();
            InsertionSort(n, array);
            time.Stop();
            textBox2.Text = "";
            for (int i = 0; i < n; i++)
                textBox2.Text += (array[i] + " ");
            TimeBox.Text = time.Elapsed.Ticks.ToString();
            algoTime = time.Elapsed.Ticks.ToString();
            TimeBox.Text += " " + n;
            
        }

        private void ExitButton_Click(object sender, EventArgs e)
        {
            StreamWriter sw = new StreamWriter("point.txt");
            sw.WriteLine(Num);
            foreach (var item in Graf)
                sw.WriteLine("{0} {1}", item.Key, item.Value);
            sw.Close();
            Application.Exit();
        }

        public void AddGraf(int index, int num)
        {
            if (!Graf.ContainsKey(index)){
                Graf.Add(index, num);
                Num++;
            }
            else
                Graf[index] = num;
        }

        private void GraphButton_Click(object sender, EventArgs e)
        {
            if (FirstClicl)
            {
                AddGraf(Len, int.Parse(algoTime));
                PaintGraf();
            }
            else
            {
                FirstClicl = true;
            }
        }

        private void PropertiesButton_Click(object sender, EventArgs e)
        {
            AboutBox pr = new AboutBox();
            pr.Show();
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            StreamWriter sw = new StreamWriter("point.txt");
            sw.WriteLine(Num);
            foreach (var item in Graf)
                sw.WriteLine("{0} {1}", item.Key, item.Value);
            sw.Close();
        }
    }
}